package org.nipa.sample;

public class StringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = new String("Hello");
		String s1 = new String("Kim");
		System.out.println(s+s1); //��Ʈ�� ��ü���� ��

	}

}
